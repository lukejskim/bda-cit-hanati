
#  4.0 의 중심, BigData

<div align='right'><font size=2 color='gray'>Data Processing Based Python @ <font color='blue'><a href='https://www.facebook.com/jskim.kr'>FB / jskim.kr</a></font>, 김진수</font></div>
<hr>

## <font color='brown'> 공공데이터 활용 </font>

### Case3. 2017 서울시 구별 CCTV 현황

http://www.data.go.kr/dataset/3074279/fileData.do;jsessionid=ZsuQWYKRZC8B4V1d9gQqzqzH.node20


```python
import platform

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from matplotlib import font_manager, rc
if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    font_name = font_manager.FontProperties(fname="C:/Windows/Fonts/malgun.ttf").get_name()
    rc('font', family=font_name)
else:
    print("It's unknown system. Hangul fonts are not supported!")
    
# plt.rcParams['axes.unicode_minus'] = False
plt.rcParams["figure.figsize"] = [12,6]

%matplotlib inline
```


```python
df = pd.read_csv('data/public_2017_seoul_cctv_st.csv', encoding='euc-kr')
df.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>경찰서</th>
      <th>개소</th>
      <th>대수</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>22</th>
      <td>구로</td>
      <td>695</td>
      <td>1,691</td>
    </tr>
    <tr>
      <th>23</th>
      <td>서초</td>
      <td>344</td>
      <td>1,079</td>
    </tr>
    <tr>
      <th>24</th>
      <td>양천</td>
      <td>763</td>
      <td>2,234</td>
    </tr>
    <tr>
      <th>25</th>
      <td>송파</td>
      <td>675</td>
      <td>779</td>
    </tr>
    <tr>
      <th>26</th>
      <td>노원</td>
      <td>1,288</td>
      <td>1,416</td>
    </tr>
    <tr>
      <th>27</th>
      <td>방배</td>
      <td>236</td>
      <td>830</td>
    </tr>
    <tr>
      <th>28</th>
      <td>은평</td>
      <td>339</td>
      <td>1,058</td>
    </tr>
    <tr>
      <th>29</th>
      <td>도봉</td>
      <td>472</td>
      <td>485</td>
    </tr>
    <tr>
      <th>30</th>
      <td>수서</td>
      <td>677</td>
      <td>1,856</td>
    </tr>
    <tr>
      <th>31</th>
      <td>총계</td>
      <td>16,603</td>
      <td>33,523</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.set_index('경찰서', inplace=True)           
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>개소</th>
      <th>대수</th>
    </tr>
    <tr>
      <th>경찰서</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>방배</th>
      <td>236</td>
      <td>830</td>
    </tr>
    <tr>
      <th>은평</th>
      <td>339</td>
      <td>1,058</td>
    </tr>
    <tr>
      <th>도봉</th>
      <td>472</td>
      <td>485</td>
    </tr>
    <tr>
      <th>수서</th>
      <td>677</td>
      <td>1,856</td>
    </tr>
    <tr>
      <th>총계</th>
      <td>16,603</td>
      <td>33,523</td>
    </tr>
  </tbody>
</table>
</div>



#### <font color='blue'> # 총계 행을 삭제 </font>


```python
df = df.drop(df.index[-1])
df.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>개소</th>
      <th>대수</th>
    </tr>
    <tr>
      <th>경찰서</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>종암</th>
      <td>295</td>
      <td>767</td>
    </tr>
    <tr>
      <th>구로</th>
      <td>695</td>
      <td>1,691</td>
    </tr>
    <tr>
      <th>서초</th>
      <td>344</td>
      <td>1,079</td>
    </tr>
    <tr>
      <th>양천</th>
      <td>763</td>
      <td>2,234</td>
    </tr>
    <tr>
      <th>송파</th>
      <td>675</td>
      <td>779</td>
    </tr>
    <tr>
      <th>노원</th>
      <td>1,288</td>
      <td>1,416</td>
    </tr>
    <tr>
      <th>방배</th>
      <td>236</td>
      <td>830</td>
    </tr>
    <tr>
      <th>은평</th>
      <td>339</td>
      <td>1,058</td>
    </tr>
    <tr>
      <th>도봉</th>
      <td>472</td>
      <td>485</td>
    </tr>
    <tr>
      <th>수서</th>
      <td>677</td>
      <td>1,856</td>
    </tr>
  </tbody>
</table>
</div>




```python
for n in np.arange(len(df)):
    df['개소'].values[n] = int(df['개소'].values[n].replace(',', ''))
    df['대수'].values[n] = int(df['대수'].values[n].replace(',', ''))

df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>개소</th>
      <th>대수</th>
    </tr>
    <tr>
      <th>경찰서</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>중부</th>
      <td>304</td>
      <td>517</td>
    </tr>
    <tr>
      <th>종로</th>
      <td>214</td>
      <td>480</td>
    </tr>
    <tr>
      <th>남대문</th>
      <td>159</td>
      <td>202</td>
    </tr>
    <tr>
      <th>서대문</th>
      <td>376</td>
      <td>1131</td>
    </tr>
    <tr>
      <th>혜화</th>
      <td>215</td>
      <td>481</td>
    </tr>
    <tr>
      <th>용산</th>
      <td>632</td>
      <td>1897</td>
    </tr>
    <tr>
      <th>성북</th>
      <td>453</td>
      <td>1276</td>
    </tr>
    <tr>
      <th>동대문</th>
      <td>486</td>
      <td>1396</td>
    </tr>
    <tr>
      <th>마포</th>
      <td>703</td>
      <td>952</td>
    </tr>
    <tr>
      <th>영등포</th>
      <td>745</td>
      <td>1122</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_sort = df.sort_values("대수", ascending=False)
df_sort.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>개소</th>
      <th>대수</th>
    </tr>
    <tr>
      <th>경찰서</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>양천</th>
      <td>763</td>
      <td>2234</td>
    </tr>
    <tr>
      <th>용산</th>
      <td>632</td>
      <td>1897</td>
    </tr>
    <tr>
      <th>수서</th>
      <td>677</td>
      <td>1856</td>
    </tr>
    <tr>
      <th>관악</th>
      <td>1042</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>구로</th>
      <td>695</td>
      <td>1691</td>
    </tr>
    <tr>
      <th>강남</th>
      <td>596</td>
      <td>1612</td>
    </tr>
    <tr>
      <th>노원</th>
      <td>1288</td>
      <td>1416</td>
    </tr>
    <tr>
      <th>동대문</th>
      <td>486</td>
      <td>1396</td>
    </tr>
    <tr>
      <th>성북</th>
      <td>453</td>
      <td>1276</td>
    </tr>
    <tr>
      <th>성동</th>
      <td>497</td>
      <td>1252</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(20,10))

sns.set_color_codes("pastel")
sns.barplot(x = df_sort.index, y = df_sort['대수'], color="b", label='대수')

sns.set_color_codes("muted")
sns.barplot(x = df_sort.index, y = df_sort['개소'], color="b", label='개소')

plt.legend(ncol=2, loc=1, frameon=True)

plt.show()
```


![png](output_11_0.png)



```python
plt.figure(figsize=(10,12))

sns.set_color_codes("pastel")
sns.barplot(x = df_sort['대수'], y = df_sort.index, color="b", label='대수')

sns.set_color_codes("muted")
sns.barplot(x = df_sort['개소'], y = df_sort.index, color="b", label='개소')

plt.legend(ncol=2, loc=4, frameon=True)

plt.show()
```


![png](output_12_0.png)



```python
df_sort.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>개소</th>
      <th>대수</th>
    </tr>
    <tr>
      <th>경찰서</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>양천</th>
      <td>763</td>
      <td>2234</td>
    </tr>
    <tr>
      <th>용산</th>
      <td>632</td>
      <td>1897</td>
    </tr>
    <tr>
      <th>수서</th>
      <td>677</td>
      <td>1856</td>
    </tr>
    <tr>
      <th>관악</th>
      <td>1042</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>구로</th>
      <td>695</td>
      <td>1691</td>
    </tr>
    <tr>
      <th>강남</th>
      <td>596</td>
      <td>1612</td>
    </tr>
    <tr>
      <th>노원</th>
      <td>1288</td>
      <td>1416</td>
    </tr>
    <tr>
      <th>동대문</th>
      <td>486</td>
      <td>1396</td>
    </tr>
    <tr>
      <th>성북</th>
      <td>453</td>
      <td>1276</td>
    </tr>
    <tr>
      <th>성동</th>
      <td>497</td>
      <td>1252</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['대수'].plot(kind='pie', fontsize=12, figsize=(10,10));
# plt.show();
```


![png](output_14_0.png)



```python
plt.figure(figsize=(15,10))
title  = "CCTV설치대수"
df_cctv = df['대수']
explode = [ 0.2 if df_cctv[i]==df_cctv.max() else 0 for i in range(len(df_cctv)) ]

plt.pie(df_cctv, 
        explode = explode,
        labels  = df_cctv.index,
        autopct = '%.2f%%', 
        shadow  = False, 
        startangle = -90,
       )
plt.legend(df_cctv.head(10))
plt.show()
```


![png](output_15_0.png)



```python
df_cctv = df['대수']
explode = [ 0.2 if df_cctv[i]==df_cctv.max() else 0 for i in range(len(df_cctv)) ]

df_cctv.plot(kind='pie', 
             title='경찰서관할 CCTV (설치대수)',
             figsize=(15, 10), 
             fontsize=12, 
             autopct='%.2f%%', 
             shadow=False, 
             startangle=-90,
             explode = explode,
            )
# plt.axis('equal')
plt.show()
```


![png](output_16_0.png)



```python
df_pbox = df['개소']
explode = [ 0.2 if df_pbox[i]==df_pbox.max() else 0 for i in range(len(df_pbox)) ]

df_pbox.plot(kind='pie', 
             title='경찰서관할 파출소 (개소수)',
             figsize=(15, 10), 
             fontsize=12, 
             autopct='%1.1f', 
             shadow=False, 
             startangle=180,
             explode = explode,
            )
# plt.axis('equal')
plt.show()
```


![png](output_17_0.png)



```python
def draw_barplot(param='v'):
    
    if param == 'h':        
        sns.set_color_codes("pastel")
        sns.barplot(x = df_sort['대수'], y = df_sort.index, color="b", label='대수')

        sns.set_color_codes("muted")
        sns.barplot(x = df_sort['개소'], y = df_sort.index, color="b", label='개소')

        plt.legend(ncol=2, loc=4, frameon=True)
    
    else:
        sns.set_color_codes("pastel")
        sns.barplot(x = df_sort.index, y = df_sort['대수'], color="b", label='대수')

        sns.set_color_codes("muted")
        sns.barplot(x = df_sort.index, y = df_sort['개소'], color="b", label='개소')

        plt.legend(ncol=2, loc=1, frameon=True)
    
    
def draw_pieplot(param):
    if param == 'CCTV':
        df_cctv = df['대수']
        explode = [ 0.2 if df_cctv[i]==df_cctv.max() else 0 for i in range(len(df_cctv)) ]

        df_cctv.plot(kind='pie', 
                     title='경찰서관할 CCTV (설치대수)',
                     fontsize=9, 
                     autopct='%.2f%%', 
                     shadow=False, 
                     startangle=-90,
                     explode = explode,
                    )
        # plt.axis('equal')
        # plt.show()
    elif param == 'PBOX':
        df_pbox = df['개소']
        explode = [ 0.2 if df_pbox[i]==df_pbox.max() else 0 for i in range(len(df_pbox)) ]

        df_pbox.plot(kind='pie', 
                     title='경찰서관할 파출소 (개소수)',
                     fontsize=12, 
                     autopct='%1.1f', 
                     shadow=False, 
                     startangle=180,
                     explode = explode,
                    )
    else :
        print("Not Operation !!")
        return 
    
    plt.axis('equal')
    # plt.show()
    
```


```python
plt.figure(figsize=(20,20))

plt.subplot(211) 
draw_barplot()

plt.subplot(223) 
draw_pieplot('CCTV')

plt.subplot(224)
draw_pieplot('PBOX')

# plt.show()
```


![png](output_19_0.png)


<hr>
<marquee><font size=3 color='brown'>The BigpyCraft find the information to design valuable society with Technology & Craft.</font></marquee>
<div align='right'><font size=2 color='gray'> &lt; The End &gt; </font></div>
